#include <stdio.h>
#include<stdlib.h>
void sortingrow(int **array1,int row,int col)
{
int i,j,k,a;
printf ("After arranging rows in ascending order\n");
 for (i=0;i<row;++i)
 {
  for (j=0;j<col;++j)
  {
   for (k=(j+1);k<col;++k)
   {
    if (array1[i][j] > array1[i][k])
    {
     a = array1[i][j];
     array1[i][j] = array1[i][k];
     array1[i][k] = a;
    }
   }
  }
 }      
 
 for (i=0;i<row;++i)
 {
  for (j=0;j<col;++j)
  {
   printf (" %d",array1[i][j]);
  }
  printf ("\n");
 }
}

int main ()
{
int m,n,i,j,count=0,b;
 printf("\nEnter the row and column of first matrix");
  scanf("%d %d",&m,&n);
int **array1=(int **)malloc(m*sizeof(int*));
	for(i=0;i<(m);i=i+1)
		{
		array1[i]=(int*)malloc(n*sizeof(int));
		}
	for(i=0;i<(m);i=i+1)
	{
	for(j=0;j<(n);j=j+1)
		{
			scanf("%d",&b);
			array1[i][j]=b;
			
		}

	}

	for(i=0;i<(m);i=i+1)
	{
	for(j=0;j<(n);j=j+1)
		{
			
			printf("%d\t\t",array1[i][j]);
			
		}
	printf("\n");

	}
 
 sortingrow(array1,m,n);
 
/* printf ("After arranging the columns in descending order \n");
 for (j=0;j<n;++j)
 {
  for (i=0;i<m;++i)
  {
   for (k=i+1;k<m;++k)
   {
    if (mb[i][j] < mb[k][j])
    {
     a = mb[i][j];
     mb[i][j] = mb[k][j];
     mb[k][j] = a;
    }
   }
  }
 }       
 
 for (i=0;i<m;++i)
 {
  for (j=0;j<n;++j)
  {
   printf (" %d",mb[i][j]);
  }
  printf ("\n");
 }*/
 
} 
