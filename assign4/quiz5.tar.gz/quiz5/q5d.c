#include<stdio.h>
#include<stdlib.h>
void multiply(int **array1,int **array2,int row1,int col2,int col1)
{
int i,j,k,sum;
int **array3=(int **)malloc(row1*sizeof(int*));
	for(i=0;i<(row1);i=i+1)
		{
		array3[i]=(int*)malloc(col2*sizeof(int));
		}
for(i=0;i<row1;i++)
      for(j=0;j<col2;j++)
           array3[i][j]=0;
      for(i=0;i<row1;i++){ //row of first matrix
      for(j=0;j<col2;j++){  //column of second matrix
           sum=0;
           for(k=0;k<col1;k++)
               sum=sum+array1[i][k]*array2[k][j];
           array3[i][j]=sum;
      }
      }
 printf("\nThe multiplication of two matrix is\n");
  for(i=0;i<row1;i++){
      printf("\n");
      for(j=0;j<col2;j++){
           printf("%d\t",array3[i][j]);
      }
  }

}
int main(){

int count=1,i,j,m,n,o,p;
printf("\nEnter the row and column of first matrix");
  scanf("%d %d",&m,&n);
  printf("\nEnter the row and column of second matrix");
  scanf("%d %d",&o,&p);
  if(n!=o){
      printf("Matrix mutiplication is not possible");
      printf("\nColumn of first matrix must be same as row of second matrix");
  }
  else{
int **array1=(int **)malloc(m*sizeof(int*));
	for(i=0;i<(m);i=i+1)
		{
		array1[i]=(int*)malloc(n*sizeof(int));
		}
	for(i=0;i<(m);i=i+1)
	{
	for(j=0;j<(n);j=j+1)
		{
			
			array1[i][j]=count;
			
		}

	}
int **array2=(int **)malloc(o*sizeof(int*));
	for(i=0;i<(o);i=i+1)
		{
		array2[i]=(int*)malloc(p*sizeof(int));
		}
	for(i=0;i<o;i++)
	{
	for(j=0;j<p;j++)
	{
			
			array2[i][j]=count;
			
	}

	}

  printf("\nThe First matrix is\n");
  for(i=0;i<m;i++){
      printf("\n");
      for(j=0;j<n;j++)
           printf("%d\t",array1[i][j]);
  }
  printf("\nThe Second matrix is\n");
  for(i=0;i<o;i++){
      printf("\n");
      for(j=0;j<p;j++)
      printf("%d\t",array2[i][j]);
   }
 multiply(array1,array2,m,p,n);  
   return 0;
}
}
