#include<stdio.h>
void test(int *ptr, int r, int c)
{
int i,j;
for(i=0;i<r;i++)
{
for(j=0;j<c;j++)
printf("%d ",(ptr[i]+j));
printf("\n");
}
}
int main()
{
int data[2][2]={1,2,3,4};
test(&data[0][0],2,2);
}
