#include<stdio.h>
#include<stdlib.h>
void sym(int **array1,int **array2,int row,int col)
{
int i,j,m=0;
for(i=0;i<row;i++)
{	
for(j=0;j<col;j++)
{	
if(array1[i][j]!=array2[i][j])
{
m++;
break;
}
}
}
if(m==1)
printf("it is a symmetric matrix\n");
else
printf("it is not a symmetric matrix\n");
}

int main()
{
int count=0,i,j;
int **array1=(int **)malloc(2*sizeof(int*));
	for(i=0;i<(2);i=i+1)
		{
		array1[i]=(int*)malloc(2*sizeof(int));
		}
	for(i=0;i<(2);i=i+1)
	{
	for(j=0;j<(2);j=j+1)
		{
			count=count+1;
			array1[i][j]=count;
			
		}

	}
int **array2=(int **)malloc(2*sizeof(int*));
	for(i=0;i<(2);i=i+1)
		{
		array2[i]=(int*)malloc(2*sizeof(int));
		}
	for(i=0;i<2;i++)
	{
	for(j=0;j<2;j++)
	{
	array2[i][j]=array1[j][i];
	}
	}
sym(array1,array2,2,2);
}
