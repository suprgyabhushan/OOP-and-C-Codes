#include<stdio.h>
#include<stdlib.h>

void Transpose(int **arr,int row,int col)
{
int i,j,a,b,f;
for(i=0;i<row;i++)
{
for(j=0,f=0;j<col;j++)
{
if(i!=j&&f==0)
continue;

a=arr[i][j];
b=arr[j][i];
arr[i][j]=b;
arr[j][i]=a;
f=1;
}
}
for(i=0;i<row;i++)
{
for(j=0;j<col;j++)
printf("%d ",arr[i][j]);

printf("\n");
}
}

int main()
{
int count=0,i,j;
int **array1=(int **)malloc(2*sizeof(int*));
	for(i=0;i<(2);i=i+1)
		{
		array1[i]=(int*)malloc(2*sizeof(int));
		}
	for(i=0;i<(2);i=i+1)
	{
	for(j=0;j<(2);j=j+1)
		{
			count=count+1;
			array1[i][j]=count;
			
		}

}
Transpose(array1,2,2);
} 
