#include<stdio.h>
#include<stdlib.h>



void findMaxnMin(int **x,int row,int col)
{
    int max=x[0][0], min= x[0][0];
        int i,j;
     
    for (i=0; i<row; i++)
        for (j=0; j<col; j++)
        {  
            if(x[i][j]> max)
            max= x[i][j];
             
            if(x[i][j]<min)
            min= x[i][j];
         
        }
printf("%d\n",max);
printf("%d\n",min);
}

int main()
{
	int count=0,i,j;
	int **array1=(int **)malloc(2*sizeof(int*));
	for(i=0;i<(2);i=i+1)
		{
		array1[i]=(int*)malloc(2*sizeof(int));
		}
	for(i=0;i<(2);i=i+1)
	{
	for(j=0;j<(2);j=j+1)
		{
			count=count+1;
			array1[i][j]=count;
			
		}
	}
	findMaxnMin(array1,2,2);
}
