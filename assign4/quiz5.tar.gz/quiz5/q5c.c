
#include<stdio.h>
#include<stdlib.h>
void add(int **array1,int **array2,int row,int col)
{
int i,j;
int **array3=(int **)malloc(2*sizeof(int*));
	for(i=0;i<(2);i=i+1)
		{
		array3[i]=(int*)malloc(2*sizeof(int));
		}
for(i=0;i<2;i++)
       for(j=0;j<2;j++)
            array3[i][j]=array1[i][j]+array2[i][j];
   printf("\nThe Addition of two matrix is\n");
   for(i=0;i<2;i++){
       printf("\n");
       for(j=0;j<2;j++)
            printf("%d\t",array3[i][j]);
   }
}
int main(){

int count=0,i,j;
int **array1=(int **)malloc(2*sizeof(int*));
	for(i=0;i<(2);i=i+1)
		{
		array1[i]=(int*)malloc(2*sizeof(int));
		}
	for(i=0;i<(2);i=i+1)
	{
	for(j=0;j<(2);j=j+1)
		{
			count=count+1;
			array1[i][j]=count;
			
		}

	}
int **array2=(int **)malloc(2*sizeof(int*));
	for(i=0;i<(2);i=i+1)
		{
		array2[i]=(int*)malloc(2*sizeof(int));
		}
	for(i=0;i<2;i++)
	{
	for(j=0;j<2;j++)
	{
			count=count+1;
			array2[i][j]=count;
			
	}

	}

  printf("\nThe First matrix is\n");
  for(i=0;i<2;i++){
      printf("\n");
      for(j=0;j<2;j++)
           printf("%d\t",array1[i][j]);
  }
  printf("\nThe Second matrix is\n");
  for(i=0;i<2;i++){
      printf("\n");
      for(j=0;j<2;j++)
      printf("%d\t",array2[i][j]);
   }
 add(array1,array2,2,2);  
   return 0;
}
