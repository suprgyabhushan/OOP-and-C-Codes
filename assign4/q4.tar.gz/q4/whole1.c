#include<stdio.h>
#include<stdlib.h>
int printall(int array[],int size)
{
if(size<=0)
{
return ;
}
else
{
printf("%d\n",array[0]);
printall(&array[1],size-1);
}
}
int main()
{
int ar[]={0,1,2,3,4};
printall(ar,5);
return 0;


}
